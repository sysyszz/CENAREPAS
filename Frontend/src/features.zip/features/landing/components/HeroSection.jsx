import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Leaf, Heart, Bookmark, ChevronLeft, ChevronRight } from 'lucide-react';
import { useConfiguracion } from '../../../shared/contexts/ConfiguracionContext';
import defaultBasketImage from '../assets/arepas-basket.png';

export function HeroSection() {
  const { nombreProyecto, eslogan, bannerImages, heroVideoUrl } = useConfiguracion();
  const [currentSlide, setCurrentSlide] = useState(0);
  const showVideo = Boolean(heroVideoUrl);

  const slides = bannerImages && bannerImages.length > 0
    ? bannerImages
    : [{ id: 'default', url: defaultBasketImage, titulo: 'Arepas Tradicionales' }];

  // Auto-play slideshow if multiple slides exist (solo aplica cuando no hay video)
  useEffect(() => {
    if (showVideo || slides.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length, showVideo]);

  const activeSlide = slides[currentSlide] || slides[0];

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  return (
    <section
      id="inicio"
      className="relative w-full h-[calc(100vh-5rem)] min-h-[560px] overflow-hidden bg-slate-900"
    >
      {/* Fondo: video de manos amasando (o carrusel de imágenes como respaldo) */}
      {showVideo ? (
        <video
          key={heroVideoUrl}
          src={heroVideoUrl}
          poster={activeSlide.url}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <img
          key={activeSlide.url}
          src={activeSlide.url}
          alt={activeSlide.titulo || nombreProyecto}
          className="absolute inset-0 w-full h-full object-cover"
        />
      )}

      {/* Degradado para legibilidad del texto */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-slate-950/10 pointer-events-none" />

      {/* Botón de Guardar flotante */}
      <button className="absolute top-6 right-6 z-20 p-2.5 bg-white/80 backdrop-blur-md rounded-full text-slate-700 hover:bg-white transition-colors shadow-md">
        <Bookmark className="w-4 h-4" />
      </button>

      {/* Flechas y puntos del carrusel (solo si no hay video y hay varios slides) */}
      {!showVideo && slides.length > 1 && (
        <>
          <button
            type="button"
            onClick={prevSlide}
            aria-label="Slide anterior"
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 size-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-all border border-white/20 cursor-pointer"
          >
            <ChevronLeft className="size-5" />
          </button>
          <button
            type="button"
            onClick={nextSlide}
            aria-label="Siguiente slide"
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 size-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-all border border-white/20 cursor-pointer"
          >
            <ChevronRight className="size-5" />
          </button>
          <div className="absolute bottom-6 right-6 z-20 flex items-center gap-1.5">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentSlide(idx)}
                aria-label={`Ir al slide ${idx + 1}`}
                className={`transition-all rounded-full ${
                  idx === currentSlide ? 'w-6 h-2 bg-accent-gold' : 'w-2 h-2 bg-white/50 hover:bg-white/80'
                }`}
              />
            ))}
          </div>
        </>
      )}

      {/* Contenido superpuesto sobre el video/imagen */}
      <div className="relative z-10 flex h-full items-end">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full px-4 pb-14 sm:px-8 sm:pb-16 lg:px-16 lg:pb-20"
        >
          <div className="max-w-2xl">
            <span className="inline-flex items-center rounded-full bg-white/15 backdrop-blur-sm px-3 py-1 text-xs font-bold uppercase tracking-[0.2em] text-white mb-4">
              Fábrica de Arepas
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.1] mb-5 drop-shadow-sm">
              {eslogan || 'Tradición, sabor artesanal y pasión por el maíz.'}
            </h1>
            <p className="text-white/85 text-base sm:text-lg mb-8 max-w-xl leading-relaxed">
              {activeSlide.subtitulo || 'Frescas, deliciosas y hechas con ingredientes 100% naturales para llevar el mejor sabor artesanal directo a tu mesa.'}
            </p>

            <div className="flex flex-wrap items-center gap-6">
              <a
                href="#productos"
                className="px-6 py-3 bg-brand text-white text-sm font-semibold rounded-full hover:bg-brand-dark transition-colors shadow-lg shadow-black/20 w-fit"
              >
                Ver productos
              </a>

              <div className="flex items-center gap-3">
                <div className="flex -space-x-3">
                  <img className="w-9 h-9 rounded-full border-2 border-white object-cover" src="https://i.pravatar.cc/100?img=1" alt="Cliente" />
                  <img className="w-9 h-9 rounded-full border-2 border-white object-cover" src="https://i.pravatar.cc/100?img=2" alt="Cliente" />
                  <img className="w-9 h-9 rounded-full border-2 border-white object-cover" src="https://i.pravatar.cc/100?img=3" alt="Cliente" />
                </div>
                <p className="text-sm text-white/80 leading-tight">
                  Más de <strong className="text-white font-semibold">15,000</strong> arepas entregadas.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-6 mt-7 pt-6 border-t border-white/20">
              <div className="flex items-center gap-2">
                <span className="flex size-8 items-center justify-center rounded-full bg-white/15 text-white">
                  <Leaf className="size-4" aria-hidden />
                </span>
                <span className="text-xs font-semibold text-white/90">100% Naturales</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex size-8 items-center justify-center rounded-full bg-white/15 text-white">
                  <Heart className="size-4" aria-hidden />
                </span>
                <span className="text-xs font-semibold text-white/90">Hechas con amor</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
