import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, MessageCircle, Mail, MapPin, Send, Check } from 'lucide-react';
import contactImage from '../assets/arepas-contact.png';

const CONTACTS = [
  { icon: Phone, text: '+57 300 123 4567', label: 'Línea de Atención' },
  { icon: MessageCircle, text: '+57 300 123 4567', label: 'WhatsApp Directo' },
  { icon: Mail, text: 'ventas@arepasdelcampo.com', label: 'Correo Electrónico' },
  { icon: MapPin, text: 'Bello Oriente, Medellín', label: 'Punto de Fábrica' },
  { icon: MapPin, text: 'Aranjuez, Medellín', label: 'Sucursal' }
];

const listContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};

const listItem = {
  hidden: { opacity: 0, x: -16 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.4 } },
};

export function ContactSection() {
  const [status, setStatus] = useState('idle'); // idle | sending | sent

  const handleSubmit = (e) => {
    e.preventDefault();
    if (status === 'sending') return;
    setStatus('sending');
    setTimeout(() => setStatus('sent'), 1200);
  };

  return (
    <section id="contacto" className="bg-slate-900 text-white py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

          {/* Columna Izquierda: Información de Contacto y Lista */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">Haz tu pedido</h2>
            <div className="mt-3 h-1 w-20 rounded-full bg-accent-gold mb-6" />
            <p className="text-slate-400 mb-10 text-lg leading-relaxed">
              Llevamos la tradición directamente a tu puerta. Escríbenos para pedidos al por mayor o eventos.
            </p>

            <motion.ul
              variants={listContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              className="space-y-6"
            >
              {CONTACTS.map(({ icon: Icon, text, label }, index) => (
                <motion.li key={`${text}-${index}`} variants={listItem} className="flex items-center gap-4">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 4 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 15 }}
                    className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center shrink-0 border border-white/10 text-brand-light"
                  >
                    <Icon className="w-5 h-5" aria-hidden />
                  </motion.div>
                  <div>
                    <p className="text-sm text-slate-400">{label}</p>
                    <p className="font-medium text-white text-base">{text}</p>
                  </div>
                </motion.li>
              ))}
            </motion.ul>
          </motion.div>

          {/* Columna Derecha: Formulario */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.12 }}
          >
            <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 backdrop-blur-md shadow-2xl relative">
              <div className="absolute -inset-3 rounded-[2.5rem] bg-brand/15 blur-xl pointer-events-none" />

              <h3 className="text-xl font-bold mb-6 text-white relative z-10">Envíanos un mensaje</h3>

              <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Nombre</label>
                  <motion.input
                    whileFocus={{ scale: 1.01 }}
                    transition={{ duration: 0.15 }}
                    type="text"
                    required
                    placeholder="Tu nombre completo"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-brand transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Correo</label>
                  <motion.input
                    whileFocus={{ scale: 1.01 }}
                    transition={{ duration: 0.15 }}
                    type="email"
                    required
                    placeholder="tucorreo@example.com"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-brand transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Mensaje o Pedido</label>
                  <motion.textarea
                    whileFocus={{ scale: 1.01 }}
                    transition={{ duration: 0.15 }}
                    rows={3}
                    required
                    placeholder="¿Qué productos necesitas?"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-brand transition-colors resize-none"
                  />
                </div>
                <motion.button
                  type="submit"
                  disabled={status === 'sending'}
                  whileHover={{ scale: status === 'idle' ? 1.02 : 1 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-brand text-white font-semibold rounded-xl px-4 py-3.5 hover:bg-brand-dark transition-colors shadow-lg shadow-brand/30 mt-2 flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {status === 'sending' && (
                    <motion.span
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 0.7, ease: 'linear' }}
                      className="size-4 border-2 border-white/40 border-t-white rounded-full"
                    />
                  )}
                  {status === 'sent' && <Check className="size-4" aria-hidden />}
                  {status === 'idle' && <Send className="size-4" aria-hidden />}
                  {status === 'sending' ? 'Enviando…' : status === 'sent' ? 'Mensaje enviado' : 'Enviar Mensaje'}
                </motion.button>
              </form>

              <div className="mt-8 overflow-hidden rounded-2xl relative aspect-[16/9] hidden sm:block">
                <img
                  src={contactImage}
                  alt="Arepas frescas servidas en un plato"
                  className="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity duration-500"
                />
              </div>

            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
