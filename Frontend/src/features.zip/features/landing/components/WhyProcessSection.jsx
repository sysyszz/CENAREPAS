import React from 'react';
import { motion } from 'framer-motion';
import { Check, Wheat, CookingPot, Flame, Package } from 'lucide-react';

const REASONS = [
  'Ingredientes 100% naturales',
  'Sin conservantes',
  'Venta por unidad y al por mayor',
  'Precios justos y competitivos',
  'Atención personalizada'
];

const STEPS = [
  { icon: Wheat, label: 'Seleccionamos los mejores ingredientes' },
  { icon: CookingPot, label: 'Preparación cuidadosa' },
  { icon: Flame, label: 'Cocción perfecta' },
  { icon: Package, label: 'Empaque higiénico y seguro' }
];

const listContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};

const listItem = {
  hidden: { opacity: 0, x: -16 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.4 } },
};

const stepsContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
};

const stepItem = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: 'easeOut' } },
};

export function WhyProcessSection() {
  return (
    <section id="ventajas" className="bg-gradient-to-br from-brand via-brand to-brand-dark py-20 text-white sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

        {/* Parte superior: ¿Por qué elegirnos? + Nuestro Proceso */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

          {/* Columna Izquierda: Razones / Ventajas */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-white sm:text-3xl">
              ¿POR QUÉ ELEGIRNOS?
            </h2>
            <div className="mt-3 h-1 w-20 rounded-full bg-accent-gold mb-6" />
            <p className="text-white/80 mb-8 text-lg leading-relaxed">
              No tomamos atajos. Respetamos la tradición para llevar a tu mesa un producto auténtico que evoca los sabores de casa.
            </p>

            <motion.ul
              variants={listContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              className="space-y-4"
            >
              {REASONS.map((reason) => (
                <motion.li key={reason} variants={listItem} className="flex items-center gap-3">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-accent-gold text-brand-dark shadow-md">
                    <Check className="size-4" strokeWidth={3} aria-hidden />
                  </span>
                  <span className="font-medium text-white/95 text-base">{reason}</span>
                </motion.li>
              ))}
            </motion.ul>
          </motion.div>

          {/* Columna Derecha: Bloque destacado del proceso */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="w-full"
          >
            <motion.div
              whileHover={{ scale: 1.015 }}
              transition={{ type: 'spring', stiffness: 250, damping: 20 }}
              className="aspect-square max-h-[400px] w-full bg-white/10 backdrop-blur-md rounded-[2.5rem] overflow-hidden relative shadow-2xl border border-white/20 flex items-center justify-center p-8"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-900/40 to-transparent pointer-events-none" />
              <div className="text-center relative z-10">
                <span className="text-xs uppercase tracking-widest text-accent-gold font-bold block mb-2">Tradición Artesanal</span>
                <h3 className="text-2xl md:text-3xl font-serif font-bold text-white mb-3">El Secreto de la Receta</h3>
                <p className="text-sm text-slate-200">Amasado sin conservantes ni químicos añadidos, conservando el sabor original del campo.</p>
              </div>
            </motion.div>
          </motion.div>

        </div>

        {/* Sección Inferior: Pasos del Proceso (Grid de 4) */}
        <div className="mt-24 pt-16 border-t border-white/10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">NUESTRO PROCESO</h2>
            <div className="mx-auto mt-3 h-1 w-20 rounded-full bg-accent-gold" />
          </motion.div>

          <motion.div
            variants={stepsContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="relative grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {STEPS.map(({ icon: Icon, label }, index) => (
              <motion.div
                key={label}
                variants={stepItem}
                className="group relative flex flex-col items-center text-center"
              >
                {index < STEPS.length - 1 ? (
                  <span className="absolute left-1/2 top-8 hidden h-px w-full border-t-2 border-dashed border-white/30 lg:block" aria-hidden />
                ) : null}
                <motion.span
                  whileHover={{ scale: 1.08, y: -4 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 15 }}
                  className="relative z-10 flex size-16 items-center justify-center rounded-full border-2 border-white/50 bg-brand shadow-lg group-hover:border-accent-gold group-hover:bg-white group-hover:text-brand transition-colors duration-300"
                >
                  <Icon className="size-7" aria-hidden />
                </motion.span>
                <span className="mt-4 text-sm font-medium leading-snug text-white/90 text-balance px-2">{label}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

      </div>
    </section>
  );
}
