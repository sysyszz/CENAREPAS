import React from 'react';
import { motion } from 'framer-motion';
import { Wheat, ShieldCheck, AlertTriangle, Sparkle } from 'lucide-react';

export function AboutSection() {
  return (
    <section id="nosotros" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mb-16"
        >
          <span className="text-xs font-bold text-brand uppercase tracking-widest">
            ¿Quiénes Somos?
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-3 leading-[1.1]">
            Tradición y calidad en cada arepa
          </h2>
          <p className="text-slate-600 text-lg leading-relaxed mt-5">
            Somos una fábrica dedicada a la producción de arepas de alta calidad, hechas cada día
            con maíz seleccionado para llevar a tu mesa un producto fresco, tradicional y nutritivo.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">

          {/* Tarjeta Izquierda: Elaboración */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Wheat className="w-5 h-5 text-brand" aria-hidden />
              <h3 className="text-lg font-bold text-slate-900">Elaboración</h3>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed mb-5 max-w-sm">
              Cada arepa se amasa a mano con maíz 100% natural, siguiendo la misma receta familiar
              desde el primer día.
            </p>

            <div className="relative rounded-2xl bg-[#fbf1e0] border border-[#ecdcbd] p-5 overflow-hidden">
              <div className="rounded-xl bg-white border border-slate-100 shadow-sm p-3 mb-3 flex items-center gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-brand/10 text-brand">
                  <Wheat className="size-4" aria-hidden />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">Amasado de la masa</p>
                  <p className="text-[11px] text-slate-400">Producción de hoy · en proceso</p>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-slate-100 shadow-sm p-3 mb-4 flex items-center gap-3">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-[#5a7a3a]/10 text-[#5a7a3a]">
                  <ShieldCheck className="size-4" aria-hidden />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">Control de calidad aprobado</p>
                  <p className="text-[11px] text-slate-400">Lote #204 · hace 2 horas</p>
                </div>
              </div>

              <div className="rounded-xl bg-slate-900 overflow-hidden shadow-lg">
                <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-800/60">
                  <span className="size-2 rounded-full bg-red-400/70" />
                  <span className="size-2 rounded-full bg-amber-400/70" />
                  <span className="size-2 rounded-full bg-green-400/70" />
                </div>
                <div className="p-4 space-y-2">
                  <div className="h-2 w-3/4 rounded bg-white/10" />
                  <div className="h-2 w-1/2 rounded bg-white/10" />
                  <div className="h-2 w-5/6 rounded bg-white/10" />
                </div>
                <div className="flex justify-center pb-4">
                  <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[11px] text-white/70">
                    <span className="size-1.5 rounded-full bg-[#e8b23d] animate-pulse" />
                    Horneando en el asador…
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Tarjeta Derecha: Control de calidad */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5 text-[#5a7a3a]" aria-hidden />
              <h3 className="text-lg font-bold text-slate-900">Cuidamos cada detalle</h3>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed mb-5 max-w-sm">
              Revisamos cada lote antes de que salga de la fábrica, para que solo llegue a tu mesa
              lo mejor del maíz.
            </p>

            <div className="relative rounded-2xl bg-[#fbf1e0] border border-[#ecdcbd] p-5 overflow-hidden">
              <div className="space-y-2.5 mb-5">
                <div className="flex items-center gap-2 text-xs font-medium text-[#8a5a14]">
                  <AlertTriangle className="size-3.5" aria-hidden />
                  Vencimiento de ingrediente próximo
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-[#8a5a14]">
                  <AlertTriangle className="size-3.5" aria-hidden />
                  Temperatura de horno fuera de rango
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-[#8a5a14]">
                  <AlertTriangle className="size-3.5" aria-hidden />
                  Lote pendiente de empaque
                </div>
              </div>

              <div className="rounded-xl bg-slate-900 overflow-hidden shadow-lg">
                <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-800/60">
                  <span className="size-2 rounded-full bg-red-400/70" />
                  <span className="size-2 rounded-full bg-amber-400/70" />
                  <span className="size-2 rounded-full bg-green-400/70" />
                  <span className="ml-auto text-[10px] text-white/40">Calidad</span>
                </div>
                <div className="flex items-center justify-center py-10">
                  <span className="flex size-16 items-center justify-center rounded-full bg-[#5a7a3a]/20 text-[#8fc25a]">
                    <span className="flex size-10 items-center justify-center rounded-full bg-[#5a7a3a]">
                      <Sparkle className="size-5 text-white" aria-hidden />
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
