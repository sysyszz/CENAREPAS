import React from 'react';
import { motion } from 'framer-motion';
import arepaImage from '../assets/arepa-amarilla.png';
import arepasX5Image from '../assets/arepas-x5.png';
import arepasX10Image from '../assets/arepas-x10.png';
import arepasYellowX5Image from '../assets/arepas-amarillas-x5.png';

const PRODUCTS = [
  {
    name: 'Arepa Amarilla',
    description: 'Hecha con maíz seleccionado, suave y deliciosa.',
    price: '$1.200',
    presentation: 'Por unidad',
    image: arepaImage,
    alt: 'Arepa amarilla de maíz en un plato'
  },
  {
    name: 'Paquete de Arepas x5',
    description: '5 arepas frescas perfectas para compartir.',
    price: '$5.000',
    presentation: '5 unidades',
    image: arepasX5Image,
    alt: 'Paquete de cinco arepas blancas',
    qty: 'x5'
  },
  {
    name: 'Paquete de Arepas x10',
    description: '10 arepas frescas ideales para toda la familia.',
    price: '$9.000',
    presentation: '10 unidades',
    image: arepasX10Image,
    alt: 'Paquete sellado de diez arepas',
    qty: 'x10'
  },
  {
    name: 'Paquete de Arepas Amarillas x5',
    description: '5 arepas amarillas llenas de sabor y tradición.',
    price: '$6.000',
    presentation: '5 unidades',
    image: arepasYellowX5Image,
    alt: 'Paquete de cinco arepas amarillas',
    qty: 'x5'
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
};

export function ProductsSection() {
  return (
    <section id="productos" className="bg-[#fbf1e0]/50 py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-brand-dark">NUESTROS PRODUCTOS</h2>
          <div className="mx-auto mt-3 h-1 w-24 rounded-full bg-accent-gold" />
          <p className="text-slate-600 max-w-2xl mx-auto mt-4 text-lg">
            Productos frescos elaborados diariamente con maíz 100% natural.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {PRODUCTS.map((product) => (
            <motion.article
              key={product.name}
              variants={cardVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm border border-slate-100 hover:shadow-xl hover:shadow-brand/10 transition-shadow duration-300"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
                <img
                  src={product.image}
                  alt={product.alt}
                  width="640"
                  height="480"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {product.qty ? (
                  <span className="absolute right-3 top-3 flex size-12 items-center justify-center rounded-full bg-brand text-sm font-extrabold text-white shadow-lg ring-2 ring-white/50">
                    {product.qty}
                  </span>
                ) : null}
              </div>

              <div className="flex flex-1 flex-col p-6 text-center">
                <h3 className="text-lg font-bold text-slate-900 mb-2">{product.name}</h3>
                <p className="text-slate-500 mb-6 text-sm leading-relaxed text-balance flex-1">{product.description}</p>

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-100">
                  <span className="text-2xl font-extrabold text-slate-900">{product.price}</span>
                  <span className="rounded-full bg-brand/10 px-3 py-1 text-xs font-semibold text-brand">
                    {product.presentation}
                  </span>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>

      </div>
    </section>
  );
}
