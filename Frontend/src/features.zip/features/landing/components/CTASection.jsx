import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, MessageCircle } from 'lucide-react';

export function CTASection() {
  return (
    <section className="bg-gradient-to-br from-brand via-brand to-brand-dark py-16 text-white sm:py-20">
      <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            ¿Listo para probar nuestras arepas?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-white/85">
            Haz tu pedido hoy mismo y recibe el sabor artesanal de siempre, directo de nuestro horno a tu mesa.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <motion.a
              href="#productos"
              whileHover={{ scale: 1.035, y: -2 }}
              whileTap={{ scale: 0.975 }}
              transition={{ type: 'spring', stiffness: 420, damping: 26 }}
              className="group inline-flex items-center gap-2.5 rounded-full bg-white py-1.5 pr-1.5 pl-5 text-sm font-semibold text-brand shadow-xl shadow-black/15 transition-colors hover:bg-white/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-brand"
            >
              Ver productos
              <span className="relative grid size-8 place-items-center overflow-hidden rounded-full bg-brand text-white">
                <ArrowRight
                  className="size-3.5 transition-transform duration-300 ease-out group-hover:translate-x-5"
                  aria-hidden="true"
                />
                <ArrowRight
                  className="absolute size-3.5 -translate-x-5 transition-transform duration-300 ease-out group-hover:translate-x-0"
                  aria-hidden="true"
                />
              </span>
            </motion.a>

            <motion.a
              href="#contacto"
              whileHover={{ scale: 1.035, y: -2 }}
              whileTap={{ scale: 0.975 }}
              transition={{ type: 'spring', stiffness: 420, damping: 26 }}
              className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-black/10 backdrop-blur-md transition-colors hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-brand"
            >
              <MessageCircle className="size-4" aria-hidden="true" />
              Hacer pedido
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
