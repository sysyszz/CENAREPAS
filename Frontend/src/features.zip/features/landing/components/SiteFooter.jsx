import React from 'react';
import { motion } from 'framer-motion';
import { useConfiguracion } from '../../../shared/contexts/ConfiguracionContext';

export function SiteFooter() {
  const { nombreProyecto } = useConfiguracion();

  return (
    <footer className="bg-slate-950 py-12 border-t border-white/10 text-white">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6"
      >

        {/* Logo y Nombre Dinámico */}
        <motion.div whileHover={{ scale: 1.03 }} className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-xs">C</span>
          </div>
          <span className="font-bold text-lg tracking-tight text-white">
            {nombreProyecto || 'CENAREPAS'}
          </span>
        </motion.div>

        {/* Derechos Reservados */}
        <p className="text-slate-500 text-sm font-medium text-center md:text-left">
          © {new Date().getFullYear()} {nombreProyecto || 'CENAREPAS'} · Todos los derechos reservados.
        </p>

        {/* Redes Sociales */}
        <div className="flex items-center gap-6 text-sm font-medium text-slate-400">
          <motion.a whileHover={{ y: -2, color: '#ffffff' }} href="#" className="hover:text-white transition-colors">
            Instagram
          </motion.a>
          <motion.a whileHover={{ y: -2, color: '#ffffff' }} href="#" className="hover:text-white transition-colors">
            Facebook
          </motion.a>
        </div>

      </motion.div>
    </footer>
  );
}
