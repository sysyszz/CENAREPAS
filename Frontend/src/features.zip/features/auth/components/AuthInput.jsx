// components/AuthInput.jsx

export const AuthInput = ({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  required = true,
  autoComplete,
}) => (
  <div className="space-y-1">
    {label && (
      <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
        {label}
      </label>
    )}
    <input
      type={type}
      value={value}
      onChange={onChange}
      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all shadow-sm"
      placeholder={placeholder}
      required={required}
      autoComplete={autoComplete}
    />
  </div>
);