// components/AuthHeader.jsx
export const AuthHeader = ({ icon: Icon, title, subtitle }) => (
  <div className="text-center mb-8">
    {Icon && (
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 mb-4 shadow-inner border border-blue-100/50">
        <Icon className="w-6 h-6" />
      </div>
    )}
    <h2 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h2>
    {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
  </div>
);