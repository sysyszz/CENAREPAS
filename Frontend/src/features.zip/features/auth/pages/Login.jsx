import React, { useState } from 'react';
import { useGoogleLogin } from '@react-oauth/google';
import { useAuth } from '../hooks/useAuth';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const { isLoading, handleLogin, handleGoogleAuth, navigate } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const success = await handleLogin(email, password);
    if (success) {
      onLogin();
      navigate('/admin');
    }
  };

  // Manejador del flujo de Google Login
  const loginWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      // Si tu custom hook 'useAuth' tiene un método para enviar el token al backend:
      if (handleGoogleAuth) {
        const success = await handleGoogleAuth(tokenResponse.access_token);
        if (success) {
          onLogin();
          navigate('/admin');
        }
      } else {
        // Modo fallback / prueba sin backend
        onLogin();
        navigate('/admin');
      }
    },
    onError: (error) => {
      console.error("Error en la autenticación con Google:", error);
    }
  });

  return (
    <div className="min-h-screen w-full flex bg-[#FFFBF0] font-sans text-[#2D2926] overflow-x-hidden selection:bg-[#C1502D]/10 selection:text-[#C1502D]">
      
      {/* PANEL IZQUIERDO — FORMULARIO */}
      <div className="w-full lg:w-[48%] xl:w-[50%] flex flex-col justify-between px-6 sm:px-12 md:px-16 lg:px-20 xl:px-24 relative bg-[#FFFBF0] py-8 lg:py-10">
        
        <div className="hidden lg:block flex-shrink-0 h-4" />

        <div className="w-full max-w-[420px] mx-auto z-10 my-auto">
          
          <div className="mb-6">
            <h1 className="text-[30px] sm:text-[34px] font-bold text-[#2D2926] leading-[1.15] tracking-tight">
              Sistema Administrativo
            </h1>
            <p className="text-[#756F6A] text-[14px] sm:text-[15px] mt-2">
              Ingresa o crea tu cuenta para continuar.
            </p>
          </div>

          {/* Credenciales de Prueba */}
          <div className="bg-[#F7F1E7] border border-[#E8E1D7] rounded-[14px] p-[16px] mb-[22px] shadow-[0_2px_8px_rgba(45,41,38,0.04)]">
            <p className="text-xs text-[#756F6A] font-medium leading-relaxed">
              <span className="block text-[#C1502D] uppercase tracking-wider mb-1.5 text-[10px] font-bold">
                Credenciales de prueba
              </span>
              <span className="block text-[#2D2926]">
                Email: <strong className="font-semibold text-[#2D2926]">admin@sistema.com</strong>
              </span>
              <span className="block text-[#2D2926]">
                Contraseña: <strong className="font-semibold text-[#2D2926]">123456</strong>
              </span>
            </p>
          </div>

          {/* Botón Google con evento conectado */}
          <button 
            onClick={() => loginWithGoogle()}
            type="button" 
            className="w-full h-[48px] flex items-center justify-center gap-3 bg-white border border-[#E8E1D7] text-[#2D2926] font-medium text-[14px] rounded-[12px] hover:bg-[#FFFBF0] hover:border-[#E8E1D7] hover:shadow-[0_4px_12px_rgba(45,41,38,0.06)] active:scale-[0.99] transition-all duration-200 shadow-[0_2px_6px_rgba(45,41,38,0.03)] cursor-pointer"
          >
            <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.58c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            <span>Continuar con Google</span>
          </button>

          {/* Divisor */}
          <div className="flex items-center my-[22px]">
            <div className="flex-grow border-t border-[#E8E1D7]"></div>
            <span className="mx-4 text-[12px] text-[#9A9289] font-medium">o continúa con</span>
            <div className="flex-grow border-t border-[#E8E1D7]"></div>
          </div>

          {/* Formulario Estándar */}
          <form onSubmit={handleSubmit} className="space-y-[18px]">
            <div>
              <label className="block text-[13px] sm:text-[14px] font-semibold text-[#2D2926] mb-[7px]">
                Correo Electrónico
              </label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="usuario@ejemplo.com" 
                autoComplete="email"
                className="w-full h-[48px] bg-white border border-[#E8E1D7] text-[#2D2926] text-[14px] placeholder-[#9A9289] rounded-[12px] px-[16px] transition-all duration-200 outline-none focus:border-[#C1502D] focus:ring-0 focus:shadow-[0_0_0_3px_rgba(193,80,45,0.10)]"
                required
              />
            </div>

            <div>
              <label className="block text-[13px] sm:text-[14px] font-semibold text-[#2D2926] mb-[7px]">
                Contraseña
              </label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"} 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••" 
                  autoComplete="current-password"
                  className="w-full h-[48px] bg-white border border-[#E8E1D7] text-[#2D2926] text-[14px] placeholder-[#9A9289] rounded-[12px] pl-[16px] pr-[44px] transition-all duration-200 outline-none focus:border-[#C1502D] focus:ring-0 focus:shadow-[0_0_0_3px_rgba(193,80,45,0.10)]"
                  required
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#9A9289] hover:text-[#C1502D] transition-colors cursor-pointer"
                  aria-label="Mostrar u ocultar contraseña"
                >
                  {showPassword ? (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  ) : (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
                  )}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center text-[13px] text-[#756F6A] cursor-pointer select-none">
                <input 
                  type="checkbox" 
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-[#E8E1D7] text-[#C1502D] accent-[#C1502D] focus:ring-0 mr-2 cursor-pointer" 
                />
                Recordarme
              </label>
              
              <button
                type="button"
                onClick={() => navigate('/admin/forgot-password')}
                className="text-[13px] font-semibold text-[#C1502D] hover:text-[#A94325] transition-colors bg-transparent border-0 cursor-pointer p-0"
              >
                ¿Olvidaste tu contraseña?
              </button>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className={`w-full h-[48px] text-white font-semibold rounded-[12px] text-[14px] px-5 transition-all duration-200 flex justify-center items-center gap-2 cursor-pointer mt-[18px] ${
                isLoading 
                  ? 'bg-[#C1502D]/70 cursor-not-allowed shadow-none' 
                  : 'bg-[#C1502D] hover:bg-[#A94325] active:translate-y-[1px] shadow-[0_5px_14px_rgba(193,80,45,0.20)] hover:shadow-[0_6px_18px_rgba(193,80,45,0.28)]'
              }`}
            >
              {isLoading && (
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              )}
              {isLoading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
            </button>
          </form>

          <div className="text-center mt-[30px]">
            <p className="text-[14px] text-[#756F6A]">
              ¿Aún no tienes una cuenta?{' '}
              <button 
                type="button"
                onClick={() => navigate('/register')} 
                className="text-[#C1502D] font-bold hover:text-[#A94325] hover:underline bg-transparent border-0 cursor-pointer p-0 ml-1 transition-colors"
              >
                Regístrate aquí
              </button>
            </p>
          </div>

        </div>

        <div className="mt-8 text-center lg:text-left text-[11px] sm:text-[12px] text-[#9A9289] font-normal z-10">
          © 2025 Winning. All rights reserved.
        </div>

      </div>

      {/* PANEL DERECHO — BRANDING / DASHBOARD */}
      <div className="hidden lg:flex lg:w-[52%] xl:w-[50%] p-4 pb-4 h-screen">
        <div className="w-full h-full bg-gradient-to-br from-[#C1502D] to-[#A94325] rounded-[20px] p-10 xl:p-12 flex flex-col justify-between relative overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.08)]">
          
          <div className="z-10 max-w-lg">
            <h2 className="text-[34px] xl:text-[38px] font-bold text-white leading-[1.1] mb-3 tracking-tight">
              Gestión Inteligente para<br />Mejores Decisiones
            </h2>
            <p className="text-white/85 text-[13px] xl:text-[14px] leading-[1.6]">
              Mantente a la vanguardia con métricas en tiempo real, análisis de rendimiento y estrategias basadas en datos. Todo en un panel de control potente y simplificado.
            </p>
          </div>

          <div className="flex-1 w-full bg-[#FFFBF0] rounded-t-[14px] shadow-[0_8px_30px_rgba(45,41,38,0.15)] overflow-hidden flex transform translate-y-6 hover:translate-y-4 transition-transform duration-500 ease-out mt-8 border border-[#E8E1D7]">
            
            <div className="w-16 md:w-44 bg-[#F7F1E7] border-r border-[#E8E1D7] p-3.5 flex flex-col gap-3">
              <div className="w-7 h-7 bg-[#C1502D] rounded-lg mb-2 flex items-center justify-center">
                <div className="w-3 h-3 bg-white rounded-sm opacity-80" />
              </div>
              <div className="w-full h-2.5 bg-[#C1502D]/20 rounded-full"></div>
              <div className="w-3/4 h-2.5 bg-[#756F6A]/20 rounded-full"></div>
              <div className="w-5/6 h-2.5 bg-[#756F6A]/20 rounded-full"></div>
              <div className="w-full h-2.5 bg-[#756F6A]/15 rounded-full mt-auto"></div>
            </div>

            <div className="flex-1 p-5 flex flex-col gap-5 bg-[#FFFBF0]">
              <div className="flex justify-between items-center">
                <div className="w-28 h-3.5 bg-[#756F6A]/20 rounded-full"></div>
                <div className="w-7 h-7 bg-[#E8B23D]/30 rounded-full border border-[#E8B23D]"></div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl shadow-[0_2px_8px_rgba(45,41,38,0.04)] border border-[#E8E1D7] flex flex-col gap-1.5">
                  <div className="w-6 h-6 bg-[#5A7A3A]/15 rounded-md flex items-center justify-center">
                    <div className="w-2 h-2 bg-[#5A7A3A] rounded-full" />
                  </div>
                  <div className="w-12 h-2 bg-[#756F6A]/30 rounded-full"></div>
                  <div className="w-16 h-3.5 bg-[#2D2926] rounded-full"></div>
                </div>

                <div className="bg-white p-3 rounded-xl shadow-[0_2px_8px_rgba(45,41,38,0.04)] border border-[#E8E1D7] flex flex-col gap-1.5">
                  <div className="w-6 h-6 bg-[#E8B23D]/20 rounded-md flex items-center justify-center">
                    <div className="w-2 h-2 bg-[#E8B23D] rounded-full" />
                  </div>
                  <div className="w-12 h-2 bg-[#756F6A]/30 rounded-full"></div>
                  <div className="w-16 h-3.5 bg-[#2D2926] rounded-full"></div>
                </div>

                <div className="bg-white p-3 rounded-xl shadow-[0_2px_8px_rgba(45,41,38,0.04)] border border-[#E8E1D7] flex flex-col gap-1.5">
                  <div className="w-6 h-6 bg-[#C1502D]/15 rounded-md flex items-center justify-center">
                    <div className="w-2 h-2 bg-[#C1502D] rounded-full" />
                  </div>
                  <div className="w-12 h-2 bg-[#756F6A]/30 rounded-full"></div>
                  <div className="w-16 h-3.5 bg-[#2D2926] rounded-full"></div>
                </div>
              </div>

              <div className="flex gap-3 flex-1 min-h-[140px]">
                <div className="flex-1 bg-white rounded-xl shadow-[0_2px_8px_rgba(45,41,38,0.04)] border border-[#E8E1D7] p-3 flex flex-col justify-end">
                  <div className="w-16 h-2.5 bg-[#756F6A]/20 rounded-full mb-auto"></div>
                  <div className="flex items-end justify-between gap-1.5 h-24 mt-2 px-1">
                    <div className="w-full bg-[#E8B23D]/50 h-[45%] rounded-t-sm"></div>
                    <div className="w-full bg-[#5A7A3A] h-[85%] rounded-t-sm"></div>
                    <div className="w-full bg-[#C1502D]/40 h-[35%] rounded-t-sm"></div>
                    <div className="w-full bg-[#C1502D] h-[95%] rounded-t-sm"></div>
                    <div className="w-full bg-[#5A7A3A]/70 h-[60%] rounded-t-sm"></div>
                  </div>
                </div>

                <div className="w-1/3 bg-white rounded-xl shadow-[0_2px_8px_rgba(45,41,38,0.04)] border border-[#E8E1D7] p-3 flex flex-col items-center justify-center">
                   <div className="w-16 h-16 rounded-full border-[6px] border-[#C1502D] border-t-[#E8B23D] border-r-[#5A7A3A]"></div>
                   <div className="w-full space-y-1.5 mt-3">
                     <div className="w-full h-1.5 bg-[#C1502D]/30 rounded-full"></div>
                     <div className="w-4/5 h-1.5 bg-[#E8B23D]/40 rounded-full"></div>
                   </div>
                </div>
              </div>

            </div>
          </div>
          
          <div className="absolute top-0 right-0 -mt-16 -mr-16 w-72 h-72 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-72 h-72 bg-black/10 rounded-full blur-2xl pointer-events-none" />
          
        </div>
      </div>

    </div>
  );
}